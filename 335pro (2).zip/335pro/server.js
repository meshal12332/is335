
const express = require('express');
const app = express();
const ridesRouter = require('./routes/rides');


app.use(express.json());


app.use('/api/rides', ridesRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
