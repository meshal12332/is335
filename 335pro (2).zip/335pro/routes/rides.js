
const express = require('express');
const router = express.Router();
const db = require('../db');


router.post('/', async (req, res) => {
  
  const { RiderID, pickupLat, pickupLon, price, vehiclerate} = req.body;

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    
    const [result] = await connection.query(
      `INSERT INTO ride (RiderID, price, pickupLocation, rideStatus, time)
       VALUES (?, ?, POINT(?, ?), 'requested', NOW())`,
      [RiderID, price, pickupLat, pickupLon]
    );

    const rideId = result.insertId;

    await connection.commit();
    res.status(201).json({
      message: 'Ride created successfully',
      rideId: rideId
    });
  } catch (error) {
    await connection.rollback();
    res.status(500).json({ error: 'Failed to create ride', details: error.message });
  } finally {
    connection.release();
  }
});


router.post('/:rideId/accept', async (req, res) => {
  const { rideId } = req.params;  
  const { driverId, plateNum } = req.body;

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [[{ distance }]] = await connection.query(
      `SELECT
         ST_Distance_Sphere(r.pickupLocation, d.Dlocation) AS distance
       FROM ride r
       JOIN driver d
         ON d.driverID = ?
       WHERE r.rideID = ?
         AND r.rideStatus = 'requested'
         FOR UPDATE`,
      [ driverId, rideId ]
    );

   
    const [rows] = await connection.query(
      `UPDATE ride
       SET driverID = ?,
           plateNum = ?,
           distance = ?,
           rideStatus = 'accepted',
           time = NOW()
       WHERE rideID = ?`,
      [driverId, plateNum, distance, rideId]
    );

    if (rows.length === 0) {
   
      await connection.rollback();
      return res.status(400).json({ error: 'Ride not found or already accepted' });
    }

    
    await connection.query(
      `UPDATE ride
       SET driverID = ?,
           rideStatus = 'accepted',
           time = NOW()
       WHERE rideID = ?`,
      [driverId, rideId]
    );

    await connection.commit();
    res.status(200).json({ message: 'Ride accepted successfully' });
  } catch (error) {
    await connection.rollback();
    res.status(500).json({ error: 'Failed to accept ride', details: error.message });
  } finally {
    connection.release();
  }
});

module.exports = router;
